const firebaseConfig = {
  apiKey: "AIzaSyAdOoqNOL9RN_Xl-shcNe5kGDz0UhqBIag",
  authDomain: "gyan-sagar-db7f6.firebaseapp.com",
  databaseURL: "https://gyan-sagar-db7f6-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "gyan-sagar-db7f6",
  storageBucket: "gyan-sagar-db7f6.appspot.com",
  messagingSenderId: "194125872627",
  appId: "1:194125872627:web:fd00699093f0871813e686",
  measurementId: "G-7PDX3LEQKB"
};
firebase.initializeApp(firebaseConfig);